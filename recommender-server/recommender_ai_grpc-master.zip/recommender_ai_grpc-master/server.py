from concurrent import futures
import logging

import grpc
import recommender_pb2
import recommender_pb2_grpc

import google.protobuf.empty_pb2

import model

from storage import Database

db = Database()


class ModelAI(recommender_pb2_grpc.ModelAIServicer):
    def Init(self, request, context):
        bios = request.bios
        genres = request.genres
        sentences_with_genres = []
        for b, g in zip(bios, genres):
            sentences_with_genres.append(b + ", " + g)

        print(sentences_with_genres)
        embeddings = model.embed_sentences(sentences_with_genres)
        ids = list(request.ids)
        db.create_database(embeddings, ids)
        return google.protobuf.empty_pb2.Empty()

    def AddBook(self, request, context):
        search_sentence = request.bio + ", " + request.genre
        embeddings = model.embed_sentences(search_sentence)
        db.save_embeddings(embeddings, request.id)
        return google.protobuf.empty_pb2.Empty()

    def DeleteBook(self, request, context):
        db.delete_book(request.id)
        return google.protobuf.empty_pb2.Empty()

    def RecommendBooks(self, request, context):
        bio = request.bio
        genre = request.genre
        str_to_emb = bio + ", " + genre
        database = db.load_database()
        closest_ids = model.get_closest_sentences(str_to_emb, request.id, request.count, database)
        return recommender_pb2.SimilarReply(ids=closest_ids)


def serve():
    port = "50051"
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    recommender_pb2_grpc.add_ModelAIServicer_to_server(ModelAI(), server)
    server.add_insecure_port("[::]:" + port)
    server.start()
    print("Server started, listening on " + port)
    server.wait_for_termination()


if __name__ == "__main__":
    logging.basicConfig()
    serve()
