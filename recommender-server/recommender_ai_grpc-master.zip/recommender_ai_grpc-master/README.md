# AI recommender server for Rust project

### running with docker
Build and run container on this port
```
docker build -t ai-audiobook-recommender .
docker run -p 50051:50051 ai-audiobook-recommender
```

### installation 

make sure you have pip installed 
```
python -m pip install virtualenv
virtualenv venv
source venv/bin/activate
python -m pip install --upgrade pip
```

install grpc for python

```
python -m pip install grpcio
python -m pip install grpcio-tools
```

now we need to install some ML dependencies, get minimal dependencies to save storage 
```
pip install transformers
pip install torch==2.1.1+cpu -f https://download.pytorch.org/whl/torch_stable.html
pip install numpy
```


### run
we need to generate grpc interface files
```
python -m grpc_tools.protoc -I./protos --python_out=. --pyi_out=. --grpc_python_out=. ./protos/recommender.proto
```
now files `recommender_{pb2.py|pb2.pyi|pb2_grcp.py}` should be generated

run to start server on default port `50051`
```
python server.py
```