import pickle

import torch

database_file = 'database.pickle'


def create_database(embeddings, ids):
    data_to_store = {
            'embeddings': embeddings,
            'ids': ids
        }
    print("Database store operation: \n", data_to_store["embeddings"].size(), ids)
    with open(database_file, 'wb') as f:
        pickle.dump(data_to_store, f)


def load_database():
    with open(database_file, 'rb') as f:
        data = pickle.load(f)
    print("Loaded database: \n", data["embeddings"].size(), data['ids'])
    return data


def save_embeddings(embeddings, book_id):
    data = load_database()
    if book_id not in data["ids"]:
        new_embeddings = torch.cat((data['embeddings'], embeddings), dim=0)
        data["embeddings"] = new_embeddings
        data["ids"].append(book_id)
    print("Saved database: \n", data["embeddings"].size(), data["ids"])
    with open(database_file, 'wb') as f:
        pickle.dump(data, f)


def delete_book(book_id):
    data = load_database()
    print("Deleting book: \n", book_id)
    idx = data['ids'].index(book_id)
    try:
        del data['ids'][idx]
        new_embeddings = torch.cat((data['embeddings'][:idx], data['embeddings'][idx + 1:]))
        data['embeddings'] = new_embeddings
    except KeyError:
        print('Book not found, skipping... ')
    with open(database_file, 'wb') as f:
        pickle.dump(data, f)
