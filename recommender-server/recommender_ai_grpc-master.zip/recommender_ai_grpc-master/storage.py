import pickle

import torch

database_file = 'database.pickle'


class Database(object):
    def __init__(self):
        self.data = {
            'embeddings': torch.Tensor(),
            'ids': [],
        }

    def create_database(self, embeddings, ids):
        self.data = {
                'embeddings': embeddings,
                'ids': ids
            }
        print("Database store operation: \n", self.data["embeddings"].size(), ids)

    def load_database(self):
        return self.data

    def save_embeddings(self, embeddings, book_id):
        if book_id not in self.data["ids"]:
            new_embeddings = torch.cat((self.data['embeddings'], embeddings), dim=0)
            self.data["embeddings"] = new_embeddings
            self.data["ids"].append(book_id)
        print("Saved database: \n", self.data["embeddings"].size(), self.data["ids"])

    def delete_book(self, book_id):
        print("Deleting book: \n", book_id)
        idx = self.data['ids'].index(book_id)
        try:
            del self.data['ids'][idx]
            new_embeddings = torch.cat((self.data['embeddings'][:idx], self.data['embeddings'][idx + 1:]))
            self.data['embeddings'] = new_embeddings
        except KeyError:
            print('Book not found, skipping... ')
