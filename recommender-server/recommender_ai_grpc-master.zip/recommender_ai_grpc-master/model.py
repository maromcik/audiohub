from typing import List, Dict

from transformers import AutoTokenizer, AutoModel
import torch
import torch.nn.functional as F

import numpy as np

# Load model from HuggingFace Hub
tokenizer = AutoTokenizer.from_pretrained('sentence-transformers/all-MiniLM-L12-v2')
model = AutoModel.from_pretrained('sentence-transformers/all-MiniLM-L12-v2')


def cosine_similarity(X, Y):
    dot_product = np.dot(X, Y.T)
    norm_X = np.linalg.norm(X, axis=1)
    norm_Y = np.linalg.norm(Y, axis=1)
    similarity = dot_product / (norm_X[:, None] * norm_Y[None, :])
    return similarity


def cosine_similarities(X, dataset):
    similarities = []
    for i in range(len(dataset)):
        similarities.append(cosine_similarity(X, dataset[i].reshape(1, -1)))
    np_similarities = np.array(similarities)
    return torch.tensor(np_similarities)


# Mean Pooling - Take attention mask into account for correct averaging
def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output[0]  # First element of model_output contains all token embeddings
    input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)


def embed_sentences(sentences: List[str]) -> torch.Tensor:
    # Tokenize sentences
    encoded_input = tokenizer(sentences, padding=True, truncation=True, return_tensors='pt')

    # Compute token embeddings
    with torch.no_grad():
        model_output = model(**encoded_input)

    # Perform pooling
    sentence_embeddings = mean_pooling(model_output, encoded_input['attention_mask'])
    print(sentence_embeddings.shape)
    # Normalize embeddings
    sentence_embeddings = F.normalize(sentence_embeddings, p=2, dim=1)

    # print("Sentence embeddings:")
    # print(sentence_embeddings)
    return sentence_embeddings


def get_closest_sentences(sentence: str, book_id, count, database) -> List[int]:
    datapoints = database['embeddings']
    ids = database['ids']
    offset = 1

    if book_id in ids:
        embedding_idx = ids.index(book_id)
        book_sentiment = datapoints[embedding_idx]
    else:
        book_sentiment = embed_sentences([sentence])
        offset = 0

    similarities = cosine_similarities(book_sentiment.reshape(1, -1), datapoints)
    similarities = similarities.flatten()

    sorted_indices = torch.argsort(torch.tensor(similarities), descending=True)
    closest_indices = sorted_indices[
                      offset:offset + count]  # Exclude the book itself (index 0) from the closest indices

    closest_ids = [ids[idx] for idx in closest_indices]
    print("Closest points are ", closest_ids)
    return closest_ids


if __name__ == '__main__':
    sentences = ['This is an example sentence', 'Each sentence is']
    sentence_embeddings = embed_sentences(sentences)
    print(sentence_embeddings.size())
